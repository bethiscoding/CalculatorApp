//
//  CalculatorViewController.swift
//  CalculatorApp
//
//  Created by Bethany Morris on 5/18/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {
    
    // MARK: - Outlets

    @IBOutlet weak var billTextField: UITextField!
    @IBOutlet weak var tipSegmentedControl: UISegmentedControl!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var billAmountLabel: UILabel!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var calculateButton: UIButton!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var tipView: UIView!
    
    var billAmount: Float = 0
    var tipPercentage: Float = 0.15
    
    var billAsString: String {
        String(format: "%.2f", billAmount)
    }
    var tipAmountAsString: String {
        String(format: "%.2f", (billAmount * tipPercentage))
    }
    var totalAsString: String {
        String(format: "%.2f", (billAmount + (billAmount * tipPercentage)))
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpViews()
        billTextField.delegate = self
    }
    
    // MARK: - Actions & Methods
    
    @IBAction func tipSegmentedControlToggled(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            tipPercentage = 0.15
        } else if sender.selectedSegmentIndex == 1 {
            tipPercentage = 0.18
        } else {
            tipPercentage = 0.20
        }
    }
    
    @IBAction func resetButtonTapped(_ sender: UIButton) {
        billTextField.text = ""
        tipLabel.text = "$0.00"
        billAmountLabel.text = "$0.00"
        tipAmountLabel.text = "$0.00"
        totalLabel.text = "$0.00"
        tipSegmentedControl.selectedSegmentIndex = 0
    }
    
    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        tipLabel.text = "$\(tipAmountAsString)"
        billAmountLabel.text = "$\(billAsString)"
        tipAmountLabel.text = "$\(tipAmountAsString)"
        totalLabel.text = "$\(totalAsString)"
    }
    
    func setUpViews() {
        self.mainView.addCornerRadius()
        tipView.addCornerRadius()
        tipLabel.addCornerRadius()
        resetButton.addCornerRadius()
    }
    
    @IBAction func mainViewTapped(_ sender: UITapGestureRecognizer) {
        billTextField.resignFirstResponder()
    }
    
} //End

extension CalculatorViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.keyboardType = .decimalPad
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        billAmount = (textField.text as! NSString).floatValue
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let dotString = "."
        
        if let text = textField.text {
            let isDeleteKey = string.isEmpty
            
            if !isDeleteKey {
                if text.contains(dotString) {
                    if text.components(separatedBy: dotString)[1].count == 2 {
                        return false
                    }
                }
            }
        }
        return true
    }
    
} //End
