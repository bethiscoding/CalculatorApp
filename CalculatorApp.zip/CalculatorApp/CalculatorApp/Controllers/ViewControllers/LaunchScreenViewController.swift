//
//  LaunchScreenViewController.swift
//  CalculatorApp
//
//  Created by Bethany Morris on 5/18/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit
import Lottie

class LaunchScreenViewController: UIViewController {
    
    @IBOutlet private var animationView: AnimationView!
    
    typealias FinishedAnimating = () -> ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startAnimation()
    }
    
    func startAnimation() {
        animationView.animation = Animation.named("money")
        
        let group = DispatchGroup()
        group.enter()
        DispatchQueue.main.async {
            self.animationView.play()
            group.leave()
        }
        
        group.notify(queue: .main) {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let calculatorViewController = storyBoard.instantiateViewController(withIdentifier: "calculatorViewController") as! CalculatorViewController
            self.present(calculatorViewController, animated: true, completion: nil)
        }
    }

} //End
