//
//  StyleGuide.swift
//  CalculatorApp
//
//  Created by Bethany Morris on 5/18/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

extension UIView {
    
    func addCornerRadius(_ radius: CGFloat = 10) {
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
}

struct FontNames {

    static let hiraginoSansBold = "Hiragino Sans W6"
}

extension UIColor {
    
    static let accentGreen = UIColor(named: "accentGreen")!
    static let mainGreen = UIColor(named: "mainGreen")!
}


//Hiragino Sans W6 28.0
